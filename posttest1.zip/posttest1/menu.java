package posttest1;

import java.util.ArrayList;
import java.util.Scanner;

public class menu {
    static String option, admin;
    static Scanner input = new Scanner(System.in);
    static artis F = new artis();//OBJEK
    static ArrayList<artis> FList;//ARRAYLIST

    public static void menu (){
        Boolean ulang,ulang2;
        System.out.println("\tWELCOME\n");
        ulang = true;
        while (ulang) {
            menuAwal();
            switch (option) {
                case "1":
                    ulang2=true;
                    while(ulang2){
                        DaftarArtis();
                        switch (admin){
                            case "1":
                                F.tambahData();
                                break;
                            case "2":
                                F.tampilData();
                                break;
                            case "3":
                                F.ubahData(FList);
                                break;
                            case "4":
                                F.hapusData();
                                break;
                            case "5":
                                ulang2=false;
                                break;
                            case "6":
                                System.err.println("\n!! Anda Telah Keluar dari Program !!\n");
                                System.exit(0);
                            default:
                                System.err.println("\n!! Pilihan Tidak Tersedia !!\n");
                                break;
                        }
                    }
                    break;
                case "2":
                    System.err.println("\n!! Anda Telah Keluar dari Program !!\n");
                    System.exit(0);

                default:
                    System.err.println("\n!! Pilihan Tidak Tersedia !!\n");
                    break;
            }
        }
    }
    public static String DaftarArtis (){
        System.out.println();
        System.out.println("Penampilan Hari Ini");
        System.out.println("1. Tambah Data");
        System.out.println("2. Tampilkan Data");
        System.out.println("3. Edit Data");
        System.out.println("4. Hapus Data");
        System.out.println("5. Kembali ke Menu Awal");
        System.out.println("6. Exit Program");
        System.out.print("Masukan Pilihan : ");
        admin = input.nextLine();
        return admin;
    }
    public static String menuAwal (){
        System.out.println();
        System.out.println("Selamat Datang di Program Pendataan Penampilan Show! Music Core");
        System.out.println("1. Penampilan Hari Ini");
        System.out.println("2. Exit Program");
        System.out.print("Masukan Pilihan : ");
        option = input.nextLine();
        return option;
    }


    public static void main(String[] args) {
        menu();
    }
}
